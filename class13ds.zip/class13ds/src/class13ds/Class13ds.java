/*
project name: class13ds
program:class13ds
Author: Erik Bailey
Date: Dec 3, 2020
Synoposis: 
make three arrays with random numbers sort with 2 different sorts and compare efficiencies
*/
package class13ds;
public class Class13ds {
    public static void main(String[] args) {
        makearr ma = new makearr();
        int size1=1000;
        int size2=100000;
        int size3=20000;
        int[] first = ma.arr(size1);
        int[] second = ma.arr(size2);
        int[] third = ma.arr(size3);
        int[] first2= new int[size1];
        int[] second2= new int[size2];
        int[] third2= new int[size3];
        System.arraycopy(first, 0, first2, 0, size1);
        System.arraycopy(second, 0, second2, 0, size2);
        System.arraycopy(third, 0, third2, 0, size3);
        time t =new time();
        t.stime(first, size1);
        t.btime(first2, size1);
        t.stime(second, size2);
        t.btime(second2, size2);
        t.stime(third, size3);
        t.btime(third2, size3);
    }
}
