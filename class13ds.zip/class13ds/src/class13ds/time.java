/*
project name: class13ds
program: time
Author: Erik Bailey
Date: Dec 4, 2020
Synoposis: 
times the process for each sort
*/
package class13ds;
public class time {
    public void stime(int[] sort, int amount){
        pass p = new pass();
        long startTime = System.currentTimeMillis();
        p.selection(sort);
        long endTime = System.currentTimeMillis();
        System.out.println("selection sort with "+ amount+" takes " + (endTime - startTime)+" to complete");        
    }
    public void btime(int[] sort, int amount){
        pass p = new pass();
        long startTime = System.currentTimeMillis();
        p.bubble(sort);
        long endTime = System.currentTimeMillis();
        System.out.println("bubble sort with "+ amount+" takes " + (endTime - startTime)+" to complete");        
    }
}
