/*
project name: class13ds
program: swap
Author: Erik Bailey
Date: Dec 3, 2020
Synoposis: 
swaps two numbers in the array
*/
package class13ds;
public class swap {
    public int[] swap(int[] a, int fir, int sec){
        int temp1=a[fir];
        int temp2=a[sec];
        a[sec]=temp1;
        a[fir]=temp2;
        return a;
    }
}