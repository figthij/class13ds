/*
project name: class13ds
program: pass
Author: Erik Bailey
Date: Dec 3, 2020
Synoposis: 
goes through one pass of the array, comparing and sorting
*/
package class13ds;
public class pass {
    public int[] bubble(int[] a){
        int count=1;
        compare c = new compare();
        swap s = new swap();
        while(count>0){
            int len =a.length;
            int res=0;//used to tell if swap 
            count=0;
            for(int i = 0; i<len-1;i++){
                res=c.comp(a, i, i+1);
                if(res==1){
                    a=s.swap(a, i, i+1);
                    count++;
                }
            }
        }
        return a;
    }
    public int[] selection(int[] a){
        int size=a.length;
        swap s = new swap();
        int small=a[0];
        int sp=0;
        for(int i=0; i<size; i++){
            small=a[i];
            sp=i;
            for(int j=i+1;j<size; j++){
                if(small>a[j])
                {
                    small=a[j];
                    sp=j;
                }
            }
                    a=s.swap(a, i, sp);
        }
        return a;
    }
}
/*        String x="";
        compare c = new compare();
        swap s = new swap();
        int len =a.length;
        int res=0;//used to tell if swap 
        int count=0;
        for(int i = 0; i<len-1;i++){
            res=c.comp(a, i, i+1);
            if(res==1){
                a=s.swap(a, i, i+1);
                x=x+"\n"+Arrays.toString(a);
                count++;
            }
        }
        if(count>0){
            return bubble(a);
        }
     */ 
/*
        for(int i=0; i<size; i++){
            int res=0;//used to tell if swap 
            for(int j=i+1; j<size; j++){
                res=c.comp(a, i, j);
                if(res==1){
                    a=s.swap(a, i, j);
        System.out.println(Arrays.toString(a));
                    
                }
                
            }
        }

*/